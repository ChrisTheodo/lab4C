#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

struct charact { 
    char ch; 
    int occurs; 
    struct charact *next;
}; 

typedef struct charact Char; 

typedef Char * ListofChar; 
typedef Char * CharNode_ptr;

void letters(char name[50], ListofChar * chars_ptr); 
void report(ListofChar chars); 
Char * createnode(char ch);

int main(void) { 
    char name[50]; 
    ListofChar chars = NULL; 
    scanf("%49s", name);  
    
    letters(name, &chars); 
    report(chars); 
    return 0; 
}  

Char * createnode(char ch) { 
    CharNode_ptr newnode_ptr ;
    newnode_ptr = malloc(sizeof (Char)); 
    newnode_ptr -> ch = ch;
    newnode_ptr -> occurs = 0; 
    newnode_ptr -> next = NULL;  
    
    return newnode_ptr; 
} 

void letters(char name[50], ListofChar * lst_ptr) {
    /* add your code */ 
    (*lst_ptr) = createnode(name[0]);

    for (int i=1;name[i]!='\0';i++){

        CharNode_ptr node = createnode(name[i]);

        node->ch = name[i];
        int j=i+1;
        
        while(name[j] != '\0'){
            if (name[j] == name[i]){
                node->occurs = j-i ;
                break;
            }
            j++;
        }


        CharNode_ptr temp = (*lst_ptr);
        while (temp->next != NULL){temp = temp->next;}
        temp->next = node;

        
    }

    return;
}

void report(ListofChar chars) { 
    /* add your code */ 
    if (chars == NULL) {
        return;
    }

    report(chars->next);
    printf("%c: %d\n", chars->ch, chars->occurs);
    
    return;
} 
