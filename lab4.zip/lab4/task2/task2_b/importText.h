#include <stdio.h>
#include <string.h>
#include <ctype.h>  
#include <stdlib.h>
#define defaultTextName "keimeno.txt"
#define defaultDictionaryName "dictionary.txt"

char **importText(char customTextName[100]){
    FILE *file;
    char textFileName[100];
    int i=0;
    
    if (customTextName[0]=='\0'){strcpy(textFileName, defaultTextName);}
    else {strcpy(textFileName, customTextName);}

    file = fopen(textFileName, "r"); 
    if (file == NULL) {
        printf("\nThe file '%s' was not found or cannot be opened!\n", textFileName);
        return 0;
    }

    ///////////////////////////////////////////////
    char lineBuffer[300]; int wordCount =0;

    while (fgets(lineBuffer, 300, file)) {
        char *ptr = strtok(lineBuffer, " \t\n\r.,;:!?\"'()[]{}");
        while (ptr != NULL) {
            //strcpy(lineBuffer[i], ptr);
            i++;
            ptr = strtok(NULL, " \t\n\r.,;:!?\"'()[]{}");
        }
        wordCount = i;
    }
    
    rewind(file);
    char** ptrsOfWords = malloc((wordCount+1) * sizeof(char*));
    i=0;

    while (fgets(lineBuffer, 300, file)) {
        char *ptr = strtok(lineBuffer, " \t\n\r.,;:!?\"'()[]{}");
        while (ptr != NULL) {
            ptrsOfWords[i] = malloc(strlen(ptr)+1);
            //*(ptrsOfWords[i]) = *ptr;
            strcpy(ptrsOfWords[i], ptr);
            i++;
            ptr = strtok(NULL, " \t\n\r.,;:!?\"'()[]{}");
        }
        
    }
    ptrsOfWords[i] = NULL;


    ///////////////////////////////////////////////////////////////////
    
    fclose(file);
    printf("\nThe file '%s' has been successfully imported!\nIf you want to pick another file, type '6' (options)", textFileName);

    return ptrsOfWords;
}

void report (char **ptrsOfWords){
    int i=0;
    while(ptrsOfWords[i] != NULL){
        printf("%s ", ptrsOfWords[i]);
        i++;
    }
}

//DEBUG AGNOHSTE
//DEBUG AGNOHSTE
//DEBUG AGNOHSTE
//DEBUG AGNOHSTE
//DEBUG AGNOHSTE
//DEBUG AGNOHSTE
//DEBUG AGNOHSTE
//DEBUG AGNOHSTE


/*int main(void){
    char **ptrs = importText("keimeno.txt");
    //report(ptrs);
*/
    /*int wordSum=0, charSum=0;
    while(ptrs[wordSum] != NULL){
        charSum += strlen(ptrs[wordSum]);
        wordSum++;
    }
    printf("wordSum: %d\ncharSum: %d\n", wordSum, charSum);*/
    
    ////////////////////////////////////////////////////////////////
    /*int charAndSpaceSum=0, letterSum=0, wordSum=0;
    int histogramStats[45] = {0};

        //lekseis-grammata
        while(ptrs[wordSum] != NULL){
        
            letterSum += strlen(ptrs[wordSum]);
            histogramStats[strlen(ptrs[wordSum])]++;
            wordSum++;
    
        }
        charAndSpaceSum = letterSum + wordSum-1;
        printf("\nLetters: %d\n Words: %d\n", letterSum, wordSum);
        printf("Istogramma lekseon/xarakthron:");
        for (int j=1; j<45; j++){
            printf("\n%d: ", j);
            for (int k=0;k<histogramStats[j]; k++){printf("#");}
        }

    return 0;
}*/