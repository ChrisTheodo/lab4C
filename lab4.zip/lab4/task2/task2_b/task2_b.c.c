#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "importText.h"

// h importText exei ta dyo functions
// importText (char **importText(char customTextName[100]))  kai 
// report (void report (char **ptrsOfWords)) (gia print)

 
#define defaultTextName "keimeno.txt"

int selectOperation(void);
void start(void);
void editMode(char **arrayOfPTRS_toText,char **arrayOfPTRS_toDict, char customDictName[100]);
void computeStats(char **arrayOfPtrs);
int unknownWordChoice(char word[46]);
void makeLowercase(char **arrayOfPtrs);
void options(char textName[100],char dictName[100]);

int main(int argc, char**argv){
    int exit = 0;
    char **text;
    char customTextName[100] = {"\0"}, customDictName[100];
    char **arrayOfPTRS_toText, **arrayOfPTRS_toDict;

    start();
    do{
        switch (selectOperation()){
            default:
                printf("\nNot a valid operation!\n");
                break;
            case 0:
                printf("\n1. Eisagogh Keimenou\n2. Eisagogh leksilogiou\n3. Epeksergasia keimenou/apothikeush leksikou\n4. Ypologismos statistikon tou keimenou\n5. eksodos\n6. Rythmiseis (onomata arxeion)\n");
                break;
            case 1:
                arrayOfPTRS_toText = importText(customTextName);
                break;
            case 2:
                arrayOfPTRS_toDict = importText(customDictName);
                break;
            case 3:
                editMode(arrayOfPTRS_toText, arrayOfPTRS_toDict, customDictName);
                break;
            case 4:
                computeStats(arrayOfPTRS_toText);
                break;
            case 5:
                exit = 1;
                break;
            case 6:
                if (argc > 1 && strcmp(argv[1], "-debug") == 0){
                    report(arrayOfPTRS_toText);
                    report(arrayOfPTRS_toDict);
                }
                else {options(customTextName, customDictName);}
                break;
        }
    } while (exit == 0);
    
    return 0;
}

void start(void){
    printf("       LAB 4 step 2_2\n\n");
    printf("Please select Existing Operations\n1. Eisagogh Keimenou\n2. Eisagogh leksilogiou\n3. Epeksergasia keimenou/apothikeush leksikou\n4. Ypologismos statistikon tou keimenou\n5. eksodos\n6. Rythmiseis (onomata arxeion)\n");
}
int selectOperation(void){
    int input;
    printf("\n\nPlease select an operation (type '0' for operation list): ");
    scanf("%d", &input);
    while (getchar() != '\n'); // katharizo to input buffer
    return input;
}

void editMode(char **arrayOfPTRS_toText,char **arrayOfPTRS_toDict, char customDictName[100]){
    int i=0,j=0,choice=0,exit=0, wordExists=0;
    char dictionaryName[100];
    
    printf("\n------Edit Mode------\n");
    printf("\n\nParakalo perimenete (mporei na parei ligh ora)\n\n");

    if (customDictName[0]=='\0'){strcpy(dictionaryName, defaultTextName);}
    else {strcpy(dictionaryName, customDictName);}

    FILE *file;
    file = fopen(dictionaryName, "a"); //prepei na to kano append kai sto leksiko
    if (file == NULL) {
        printf("Den brethike leksiko. Parakalo kante to prota import.\n");
        return;
    }

    if (arrayOfPTRS_toText[0] == NULL){
        printf("Den brethike keimeno. Parakalo kante to prota import.\n");
        return;
    }

    if (arrayOfPTRS_toDict[0] == NULL){
        printf("Den brethike leksiko. Parakalo kante to prota import.\n");
        return;
    }
    
    makeLowercase(arrayOfPTRS_toText);
    makeLowercase(arrayOfPTRS_toDict);

    while(arrayOfPTRS_toText[i] != NULL){
        wordExists=0;
        j=0;

        while(arrayOfPTRS_toDict[j]!=NULL){
            if (strcmp(arrayOfPTRS_toText[i], arrayOfPTRS_toDict[j])==0) {wordExists = 1;j++;break;}
            else {j++;continue;}
        }

        if (wordExists ==0){
            choice = unknownWordChoice(arrayOfPTRS_toText[i]);
            if (choice ==1){
                fprintf(file, "\n%s", arrayOfPTRS_toText[i]);
            }
            else if (choice ==2){}
            else if (choice ==3){exit =1; break;}
        }
        i++;
    }

    fclose(file);

}

void computeStats(char **arrayOfPtrs){
    int letterSum = 0, wordSum=0, charAndSpaceSum=0,i=0,epilogh=0;
    int histogramStats[45] = {0}; //h megalyterh agglikh leksh..
    char fileName[100];
    
    printf("\n1: emfanise statistika\n2: apothikeuse statistika");
    printf("\nPlease select an operation: ");
    scanf("%d", &epilogh);
    

    //lekseis-grammata
    while(arrayOfPtrs[wordSum] != NULL){
        
        letterSum += strlen(arrayOfPtrs[wordSum]);
        histogramStats[strlen(arrayOfPtrs[wordSum])]++;
        wordSum++;

    }
    charAndSpaceSum = letterSum + wordSum-1;


    switch(epilogh){
        default: printf("\nNot a valid operation!\n");break;
        
        case 1:
            printf("\nLetters: %d\n Words: %d\n", letterSum, wordSum);
            printf("Istogramma lekseon/xarakthron:");
            for (int j=1; j<45; j++){
                printf("\n%d: ", j);
                for (int k=0;k<histogramStats[j]; k++){printf("#");}
            }
            break;
        
        case 2:
            printf("\nDose onoma arxeiou statistikon (xoris extension): "); scanf("%s", fileName);
            strcat(fileName, ".txt");
            FILE *file = fopen(fileName, "w");
            fprintf(file, "\nLetters: %d\n Words: %d\n\nIstogramma lekseon/xarakthron:", letterSum, wordSum);
            for (int j=1; j<45; j++){
                fprintf(file, "\n%d: ", j);
                for (int k=0;k<histogramStats[j]; k++){fprintf(file, "#");}
            }
            fclose(file);
            printf("'%s' has been made successfully!", fileName);
            break;      
    }
    
}


void makeLowercase(char **arrayOfPtrs){
    int i=0;
    while (arrayOfPtrs[i]!= NULL){
        int j=0;
        while(arrayOfPtrs[i][j]!='\0'){
            arrayOfPtrs[i][j] = tolower(arrayOfPtrs[i][j]);
            j++;
        }
        i++;
    }
}

int unknownWordChoice(char word[46]){
    int choice;
    printf("\nBrethike agnosth leksh: '%s'\n", word);
    
    while(1){
        printf("\nEpilogh (pata 0 gia lista epilogon): ");
        scanf("%d", &choice);
        switch (choice){
            default: printf("\nDen yparxei auth h epilogh.\n");while (getchar() != '\n'); break;
            case 0: printf("\n1: prosthikh ths lekshs '%s' sto leksiko\n2: Agnohse to\n3. Eksodos apo leitourgia epeksergasias\n"); break;
            case 1: printf("\nH leksh '%s' prostethike sto leksiko!\n", word); return 1;
            case 2: printf("\nParablepsh ths lekshs '%s'..\n", word);return 2;
            case 3: printf("\nGinetai eksodos apo th leitourgia epeksergasias.."); return 3;
        }
    }
}

void options(char customTextName[100],char customDictName[100]){
    printf("\n\nSelect text file name (xoris extension): ");
    scanf("%100s", customTextName);
    strcat(customTextName, ".txt");
    printf("\n\nSelect dictionary file name (xoris extension): ");
    scanf("%100s", customDictName);
    strcat(customDictName, ".txt");
    #undef defaultTextName
}