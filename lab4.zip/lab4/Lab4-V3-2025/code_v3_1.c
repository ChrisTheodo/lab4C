/* code_v3_1.c */

#include <stdio.h>
#include <string.h>
struct charact
{
    char ch;
    int sec;
};
typedef struct charact Char;

Char distance(char name[50]);
void report(Char temp);

int main(void)
{
    char name[50];
    Char first;
    scanf("%49s", name);
    first = distance(name);
    report(first);

    return 0;
}

Char distance(char name[50])
{
    Char temp;
    /* Your code here! No printf or equivalent!!! (6 to 10 lines) */
    return temp;
}

void report(Char t)
{
    /* Your code here! (two lines) */
    return;
}
