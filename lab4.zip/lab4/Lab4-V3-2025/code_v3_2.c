/* code_v3_2.c */

#include <stdio.h>
#include <string.h>

struct charact
{
    char ch;
    int sec;
};
typedef struct charact Char;

void letters(char name[50], Char chars[50]);
void report(Char chars[50]);

int main(void)
{
    char name[50];
    Char chars[50];

    scanf("%49s", name);
    letters(name, chars);
    report(chars);

    return 0;
}

void letters(char name[50], Char chars[50])
{
    size_t i, j;
    memset(chars, 0, 50*sizeof (Char));
    /* Your code here! No printfs or equivalent 
    (No more than 15 lines, are required.
    Can be done with less) */
    return;
}
void report(Char t[50])
{
    /* your code here (5-6 lines) */
    return;
}

