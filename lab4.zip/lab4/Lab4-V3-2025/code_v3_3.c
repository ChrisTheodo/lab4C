/* code_v3_3.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHARS 10

char **readText(int *words);

int main(void)
{

    char **mytext;
    int i, words;

    mytext = readText(&words);

    for (i = 0; i < words; i++)
        printf("%s\n", mytext[i]);

    return 0;
}

char **readText(int *words)
{
    char **mytext = NULL;
    char *word;
    int i;

    *words = 0;
    while (scanf("%s", word = malloc(CHARS * sizeof(char))), strcmp(word, "END"))
    {
        (*words)++;
        mytext = realloc(mytext, (*words) * sizeof(char *));
        mytext[*words - 1] = word;
    }
    free(word);

    return mytext;
}
